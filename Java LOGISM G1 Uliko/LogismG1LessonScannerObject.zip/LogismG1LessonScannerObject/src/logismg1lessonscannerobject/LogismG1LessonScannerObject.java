/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package logismg1lessonscannerobject;

import java.util.Scanner;

/**
 *
 * @author PE3
 */
public class LogismG1LessonScannerObject {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("Please give your age: ");
        int num = in.nextInt();
        in.nextLine();
        System.out.print("Please give your name: ");
        String s = in.nextLine();
        System.out.printf("My name is %s and my age is %d"
        ,s,num);
        
    }
    
}
